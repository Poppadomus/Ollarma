OLLAMA TALK - Arma 3 civilian dialogue (singleplayer)

STEP 1  Copy the CONTENTS of the copy_into_your_mission folder into your own mission folder
        (next to your mission.sqm):  ollama_talk folder, description.ext, init.sqf
        If you already have a description.ext or init.sqf, do not overwrite them -
        merge in the lines instead (CfgFunctions block / the init.sqf lines).
STEP 2  Copy ollama_bridge_x64.dll into your Arma 3 GAME folder, next to arma3_x64.exe.
        Right-click it > Properties > tick Unblock if shown.
STEP 3  Make sure Ollama is running and: ollama pull llama3.2
STEP 4  Start Arma 3 with arma3_x64.exe (skips BattlEye), open your mission and Preview.
        Use the "Talk" action on the civilian. Replies show in the bottom-left chat feed.

init.sqf uses a civilian named civ1 if you placed one; otherwise it spawns one in front of you.
The chat feed should first say "ollama_bridge ping: pong".
